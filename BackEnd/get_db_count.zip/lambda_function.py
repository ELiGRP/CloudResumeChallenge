import json
import boto3
from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return json.JSONEncoder.default(self, obj)

def lambda_handler(event, context):
    
    client = boto3.resource('dynamodb')
    table = client.Table('cloud-resume-challenge')
    
    table.update_item(
        Key={'ID': 'Visitors'},
        UpdateExpression= "SET num= num + :n",
        ExpressionAttributeValues= {':n': 1},
        ReturnValues="UPDATED_NEW",
        )
    message = table.get_item(
        Key={'ID': 'Visitors'},
        ProjectionExpression= 'num',
        )
    
        
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        'body': json.dumps(message["Item"],cls=DecimalEncoder)}